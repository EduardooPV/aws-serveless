const { SQSClient, SendMessageCommand } = require('@aws-sdk/client-sqs');

const isLocalStack = process.env.LOCALSTACK_HOSTNAME ? true : false;

const config = {
  region: "us-east-1",
  endpoint: isLocalStack
    ? `http://${process.env.LOCALSTACK_HOSTNAME}:4566`
    : "http://localhost:4566"
};

const sqsClient = new SQSClient(config);

exports.handler = async (event) => {
  console.log("⚡ Lambda recepcionista acionada!");


  let filaUrl = process.env.QUEUE_URL;

  if (isLocalStack && filaUrl) {
    filaUrl = filaUrl.replace(/localhost|sqs\.[a-z0-9-]+\.localhost\.localstack\.cloud/, process.env.LOCALSTACK_HOSTNAME);
    console.log(`🔄 URL da Fila corrigida para rede interna: ${filaUrl}`);
  }

  const ordemId = "ORD-LAMBDA-" + Date.now();

  const novaOrdem = {
    id_ordem: ordemId,
    cliente: "Maria Lambda",
    acao: "VALE3",
    quantidade: 50,
    preco: 60.00,
    data: new Date().toISOString()
  };

  try {

    const command = new SendMessageCommand({
      QueueUrl: filaUrl,
      MessageBody: JSON.stringify(novaOrdem)
    })

    await sqsClient.send(command);
    console.log(`✅ Ordem ${ordemId} enviada para a fila SQS`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        mensagem: "Ordem recebida com sucesso. Estamos processando.",
        protocolo: ordemId
      })
    };


  } catch (erro) {
    console.error("❌ Erro:", erro);
    return { statusCode: 500, body: erro.message };
  }
};