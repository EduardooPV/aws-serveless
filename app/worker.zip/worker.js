const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");

const isLocalStack = process.env.LOCALSTACK_HOSTNAME ? true : false;
const config = {
  region: "us-east-1",
  endpoint: isLocalStack
    ? `http://${process.env.LOCALSTACK_HOSTNAME}:4566`
    : "http://localhost:4566"
};

const s3Client = new S3Client(config);
const dynamoClient = new DynamoDBClient(config);
const docClient = DynamoDBDocumentClient.from(dynamoClient);

exports.handler = async (event) => {
  for (const record of event.Records) {
    try {
      const body = JSON.parse(record.body);

      console.log("------------------------------------------------");
      console.log("👷 WORKER INICIADO");
      console.log(`📥 Processando Pedido ID: ${body.id_ordem}`);


      const paramsDynamo = {
        TableName: "Ordens",
        Item: {
          id: body.id_ordem,
          ...body,
          status: "PROCESSADO_COM_SUCESSO",
          data_processamento: new Date().toISOString()
        }
      };

      await docClient.send(new PutCommand(paramsDynamo));
      console.log(`💾 Salvo no DynamoDB (Tabela Ordens)`);

      const paramsS3 = {
        Bucket: "arquivos-corretora",
        Key: `comprovante-${body.id_ordem}.json`,
        Body: JSON.stringify(body, null, 2),
        ContentType: "application/json"
      };

      await s3Client.send(new PutObjectCommand(paramsS3));
      console.log(`💾 Arquivo salvo no S3 (arquivos-corretora)`);

      console.log("✅ Compra Efetivada e Persistida!");
      console.log("------------------------------------------------");

    } catch (erro) {
      console.error("❌ Falha crítica ao processar mensagem:", erro);

      throw erro;
    }
  }
};